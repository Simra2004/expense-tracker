<?php
include('config.php');
include('functions.php');
?>
<html>
	<head>
	    <link rel="stylesheet" href="CSS/dashboard.css">
		<link rel="stylesheet" href="CSS/reports.css">
		<link rel="stylesheet" href="CSS/users.css">
		<link rel="stylesheet" href="CSS/expense.css">
		<link rel="stylesheet" href="CSS/login.css">
		<link rel="stylesheet" href="CSS/admin-category.css">
		<link rel="stylesheet" href="CSS/manage-expense.css">
		<link href="https://fonts.googleapis.com/css2?family=Roboto&display=swap" rel="stylesheet">
		<link href='https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.2/css/all.min.css' rel='stylesheet'>
	
<link href='https://fonts.googleapis.com/css2?family=Inter+Tight:ital,wght@0,100..900;1,100..900&family=Inter:wght@100..900&family=Rowdies:wght@300;400;700&display=swap'>

		<title>
		
		</title>
		

	</head>
	<div class="bg">
		
	</div>